from django.http import HttpResponse, HttpResponseRedirect, FileResponse
from django.shortcuts import render
from datetime import datetime
# Package Form
from .forms import TaskCreatePost
from .forms2 import DatasetCreatePost
# Package Model
from .models import Task, Dataset

from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as django_logout
from django.contrib.auth.decorators import login_required

from django.contrib.auth.models import User


def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user_log = authenticate(request, username=username, password=password)
        if user_log is not None:
            auth_login(request, user_log)
            return HttpResponseRedirect("home")
        else:
            return HttpResponseRedirect("/")

    return render(request, "login.html")


def register(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = User.objects.create_user(username, email, password)
        return HttpResponseRedirect("/")

    return render(request, "register.html")


@login_required(login_url='/')
def index(request):

    all_task = Task.objects.filter(deleted_date__isnull=True)
    all_task_booking = Task.objects.filter(
        status_task='Booking', deleted_date__isnull=True)

    context = {
        'title_page': 'Task Planner Management',
        'all_task': all_task,
        'all_task_booking': all_task_booking,
    }
    return render(request, "index.html", context)


@login_required(login_url='/')
def upload_management(request):

    all_dataset = Dataset.objects.all()
    context = {
        'title_page': 'Upload Dataset Management',
        'all_dataset': all_dataset,
    }
    return render(request, "upload_management.html", context)


@login_required(login_url='/')
def download_dataset(request, id_dataset):
    obj = Dataset.objects.get(id_dataset=id_dataset)
    filename = obj.file_dataset.path
    response = FileResponse(open(filename, 'rb'))
    return response


@login_required(login_url='/')
def upload_dataset(request):

    # Method Form Dataset
    createDataset = DatasetCreatePost()

    # Check if method is post
    if request.method == "POST":
        # Save Original Dataset
        test_dataset = Dataset(name_dataset=request.POST.get(
            'name_dataset'), file_dataset=request.FILES['file_dataset'])
        test_dataset.save()

        return HttpResponseRedirect("upload_management")

    context = {
        'title_page': 'Upload Dataset Management',
        'createDataset': createDataset,
    }
    return render(request, "upload_dataset.html", context)


@login_required(login_url='/')
def logout(request):
    django_logout(request)
    return HttpResponseRedirect("/")


@login_required(login_url='/')
def create_task(request):
    # Method Form Task
    createTask = TaskCreatePost()

    # Check if method is post
    if request.method == "POST":
        title_task_post = request.POST.get('title_task')
        status_task_post = request.POST.get('status_task')
        progress_task_post = request.POST.get('progress_task')
        notes_task_post = request.POST.get('notes_task')

        # Save Task Data
        test_task = Task(title_task=title_task_post, status_task=status_task_post,
                         progress_task=progress_task_post, notes_task=notes_task_post)
        test_task.save()

        return HttpResponseRedirect("/")

    context = {
        'title_page': 'Adding Task',
        'createTask': createTask,
    }

    return render(request, "manage_task.html", context)


@login_required(login_url='/')
def update_task(request, id_update):

    task_update = Task.objects.get(id_task=id_update)

    data = {
        'title_task': task_update.title_task,
        'progress_task': task_update.progress_task,
        'status_task': task_update.status_task,
        'notes_task': task_update.notes_task,
    }

    updateTask = TaskCreatePost(
        request.POST or None, request.FILES or None, initial=data, instance=task_update)

    if request.method == "POST":
        if updateTask.is_valid():
            updateTask.save()
        return HttpResponseRedirect("/")

    context = {
        'title_page': 'Update Task',
        'createTask': updateTask,
    }

    return render(request, "manage_task.html", context)


@login_required(login_url='/')
def booking_task(request, id_update):
    Task.objects.filter(id_task=id_update).update(status_task='Booking')
    return HttpResponseRedirect("/")


@login_required(login_url='/')
def revoke_booking_task(request, id_update):
    Task.objects.filter(id_task=id_update).update(status_task='Revoke')
    return HttpResponseRedirect("/")


@login_required(login_url='/')
def soft_delete_task(request, id_update):
    Task.objects.filter(id_task=id_update).update(deleted_date=datetime.now())
    return HttpResponseRedirect("/")


@login_required(login_url='/')
def delete_task(request, id_delete):
    Task.objects.filter(id_task=id_delete).delete()
    return HttpResponseRedirect("/")
