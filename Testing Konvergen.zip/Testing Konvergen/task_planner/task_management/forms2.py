from django import forms

from .models import Dataset


class DatasetCreatePost(forms.ModelForm):

    class Meta:
        model = Dataset
        fields = ['name_dataset', 'file_dataset']

    name_dataset = forms.CharField(
        label="Nama Dataset",
        max_length=100,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter Nama Dataset',
                'style': 'margin-top:1%'
            }
        )
    )

    file_dataset = forms.FileField(
        label="Dataset File",
        required=False,
    )
