from django import forms

from .models import Task


class TaskCreatePost(forms.ModelForm):

    class Meta:
        model = Task
        fields = ['status_task', 'title_task', 'progress_task', 'notes_task']

    title_task = forms.CharField(
        label="Nama Task",
        max_length=100,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter Nama Task',
                'style': 'margin-top:1%'
            }
        )
    )

    status_task = forms.CharField(
        label="Status Task",
        max_length=15,
        disabled=True,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter Status Task',
                'style': 'margin-top:1%'
            }
        )
    )

    progress_task = forms.IntegerField(
        label="Progress Task",
        widget=forms.TextInput(
            attrs={
                'type': 'number',
                'class': 'form-control',
                'placeholder': 'Enter Progress Task (%)',
                'style': 'margin-top:1%'
            }
        )
    )

    notes_task = forms.CharField(
        label="Notes Task",
        widget=forms.Textarea(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter Notes Task',
                'style': 'margin-top:1%'
            }
        )
    )
