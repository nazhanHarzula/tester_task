from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    path('', views.login, name="login"),
    path('register/', views.register, name="register"),
    path('home/', views.index, name="index_home"),
    path('logout/', views.logout, name="logout_auth"),
    path('upload/', views.upload_management, name="upload_management"),
    path('create_task/', views.create_task, name="create_task"),
    path('upload_dataset/', views.upload_dataset, name="upload_dataset"),
    path('download_dataset/<int:id_dataset>',
         views.download_dataset, name="download_dataset"),
    path('update_task/<int:id_update>',
         views.update_task, name="update_task"),
    path('booking_task/<int:id_update>',
         views.booking_task, name="booking_task"),
    path('revoke_booking_task/<int:id_update>',
         views.revoke_booking_task, name="revoke_booking_task"),
    path('soft_delete_task/<int:id_update>',
         views.soft_delete_task, name="soft_delete_task"),
    path('delete_task/<int:id_delete>',
         views.delete_task, name="delete_task"),
]
