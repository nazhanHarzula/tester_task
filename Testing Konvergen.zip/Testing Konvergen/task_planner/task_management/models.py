from django.db import models


class Task(models.Model):
    id_task = models.AutoField(primary_key=True)
    title_task = models.CharField(max_length=100, blank=True, null=True)
    status_task = models.CharField(max_length=15, blank=True, null=True)
    progress_task = models.IntegerField(blank=True, null=True)
    notes_task = models.TextField(blank=True, null=True)
    deleted_date = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return self.title_task


class Dataset(models.Model):
    id_dataset = models.AutoField(primary_key=True)
    name_dataset = models.CharField(max_length=100, blank=True, null=True)
    file_dataset = models.FileField(
        max_length=300, blank=True, null=True, upload_to='dataset_management/')

    def __str__(self):
        return self.title_task
